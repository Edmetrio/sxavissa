

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h4 class="header-title">Formulário de Artigo</h4>
                <p class="sub-header">
                    Formulário de Cadastro de Artigo: é especialmente utilizado para o registo de todos artigos
                </p>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Opss!</strong> Algum problema com seu formulário<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if(isset($artigo)): ?>
                <form method="POST" enctype="multipart/form-data" action="<?php echo e(url("")); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php else: ?>
                    <form action="<?php echo e(url('artigo')); ?>" method="POST" enctype="multipart/form-data">
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputCity" class="col-form-label">Nome da Categoria</label>
                                <input type="text" class="form-control" placeholder="Televisão" name="nome" value="">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputState" class="col-form-label">Categoria</label>
                                <select name="categoria_id" class="form-control">
                                    <option value=""></option>
                                    <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->nome); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputState" class="col-form-label">Subcategoria</label>
                                <select name="subcategoria_id" class="form-control">
                                    <option value=""></option>
                                    <?php $__currentLoopData = $subcategoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($s->id); ?>"><?php echo e($s->nome); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputState" class="col-form-label">Tipo</label>
                                <select name="tipo_id" class="form-control">
                                    <option value=""></option>
                                    <?php $__currentLoopData = $tipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($t->id); ?>"><?php echo e($t->nome); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputCity" class="col-form-label">Icon</label>
                                <input type="file" class="form-control" name="icon">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputCity" class="col-form-label">Preço</label>
                                <input type="number" class="form-control" placeholder="20" name="preco" value="">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputCity" class="col-form-label">Iva</label>
                                <input type="text" class="form-control" name="iva">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputCity" class="col-form-label">Desconto</label>
                                <input type="number" class="form-control" placeholder="20" name="desconto" value="">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputCity" class="col-form-label">Garantia</label>
                                <input type="number" class="form-control" placeholder="20" name="desconto" value="">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary"><?php if(isset($artigo)): ?>Alterar <?php else: ?> Adicionar <?php endif; ?></button>
                    </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\syxavissa\resources\views/createArtigo.blade.php ENDPATH**/ ?>