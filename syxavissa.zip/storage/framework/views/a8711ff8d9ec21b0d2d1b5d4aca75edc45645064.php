

<?php $__env->startSection('content'); ?>


    
<div class="content">

<!-- Start Content-->
<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Lista das Subcategorias</h4>
                    <div class="input-group-append" style="float: right;">
                            <a href="<?php echo e(url('subcategoria/create')); ?>">Adicionar</a>
                        </div>
                    <p class="text-muted font-13 mb-4">
                        Subcategorias: são subfases de uma categoria
                    </p>
                    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert" style="text-align: center; font-weight: bold;">
            <p class="status"><?php echo e(session('status')); ?></p>
        </div>
        <?php endif; ?>
                    <table id="basic-datatable" class="table table-bordered dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Categoria</th>
                                <th>Ícon</th>
                                <th>Acções</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $subcategoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($s->nome); ?></td>
                                <td><?php echo e($s->categorias->nome); ?></td>
                                <td><img class="img-fluid" src="assets/images/subcategoria/<?php echo e($s->icon); ?>" alt="Product" style="width: 30px; text-align: center;"/></td>
                                <td><a href="<?php echo e(url("subcategoria/$s->id/edit")); ?>">Alterar</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> 

</div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\syxavissa\resources\views/subcategoria.blade.php ENDPATH**/ ?>